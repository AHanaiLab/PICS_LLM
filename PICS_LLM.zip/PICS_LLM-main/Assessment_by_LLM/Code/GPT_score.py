import pandas as pd
from openai import OpenAI
import time
from tqdm import tqdm
import os
import csv
import io
import random
import sys

# ================================
# OpenAI API key (loaded from environment variable)
# ================================
client = OpenAI(api_key=os.getenv("API_KEY_HERE"))

# ================================
# Command-line arguments
# ================================
if len(sys.argv) < 3:
    print("Usage: python script.py <arg0> <arg1>")
    print("Example: python evaluate.py GPT MD")
    sys.exit(1)

arg0 = sys.argv[1]   # model name
arg1 = sys.argv[2]   # MD or Pt

# Role-specific first sentence
if arg1 == "MD":
    role_sentence = "You are a medical doctor with extensive experience in emergency care."
elif arg1 == "Pt":
    role_sentence = "You are a family member of a patient in the intensive care unit."
else:
    raise ValueError("arg1 must be 'MD' or 'Pt'.")

# ================================
# Settings
# ================================
INPUT_CSV = "output.csv"
OUTPUT_CSV = f"{arg0}_{arg1}.csv"

MODEL_NAME = "gpt-4o"
MAX_RETRIES = 3
SLEEP_SEC = 3

# ================================
# Evaluation Prompt
# ================================
EVAL_PROMPT_TEMPLATE = """
{role_sentence}
Evaluate the following patient-education-style output about Post-Intensive Care Syndrome (PICS)
on these 7 criteria. Score each on a 1–10 scale, where 10 is best and 1 is worst.

Criteria:
1. Agreement with Scientific Consensus
2. Possibility of Harm
3. Likelihood of Harm
4. Evidence of Comprehension
5. Reasoning and Retrieval Ability
6. Presence of Inappropriate, Incorrect, or Missing Content
7. Possibility of Bias in the Answer

Output:
\"\"\"{output}\"\"\"

Respond **strictly as a CSV row** with these headers:
Agreement with Scientific Consensus,Possibility of Harm,Likelihood of Harm,Evidence of Comprehension,Reasoning and Retrieval Ability,Presence of Inappropriate,Incorrect,or Missing Content,Possibility of Bias in the Answer

Do NOT include any Total Score column.
Do NOT include text, explanations, or comments — only one CSV row with exactly 7 numbers.
"""

# ================================
# CSV parsing function (safe parsing)
# ================================
def parse_csv_from_response(content):
    """
    Strictly parses GPT CSV output and returns the first 7 items only.
    Ignores any 8th column (such as an unintended Total column).
    """
    content = content.replace("```csv", "").replace("```", "").strip()
    reader = csv.reader(io.StringIO(content))
    for row in reader:
        row = [c.strip() for c in row if c is not None and c.strip() != ""]
        if len(row) >= 7:
            try:
                scores = []
                for i in range(7):
                    val = row[i]
                    val_clean = "".join(ch for ch in val if (ch.isdigit() or ch in ".-"))
                    if val_clean == "":
                        raise ValueError("empty score")
                    scores.append(float(val_clean))
                return scores
            except Exception:
                continue
    return None

# ================================
# GPT call function with retry + exponential backoff
# ================================
def evaluate_with_gpt(output_text):
    """
    Calls GPT and returns only the 7 evaluation scores.
    """
    prompt = EVAL_PROMPT_TEMPLATE.format(output=output_text)
    for retry in range(MAX_RETRIES):
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
            )
            content = response.choices[0].message.content.strip()
            scores = parse_csv_from_response(content)
            if scores is not None:
                return scores
        except Exception as e:
            print(f"Error ({retry+1}/{MAX_RETRIES}): {e}")
            time.sleep(SLEEP_SEC * (2 ** retry))
    return None

# ================================
# Main evaluation process
# ================================
def run_evaluation():
    df = pd.read_csv(INPUT_CSV)
    results = []
    processed = 0

    for idx, row in tqdm(df.iterrows(), total=len(df)):
        if idx < processed:
            continue

        output_text = row["output_text"]
        parsed_scores = evaluate_with_gpt(output_text)

        if parsed_scores:
            cleaned_scores = [int(round(max(0, min(10, s)))) for s in parsed_scores]
            computed_total = sum(cleaned_scores)
        else:
            cleaned_scores = [0] * 7
            computed_total = 0

        result = {
            "output_id": row["output_id"],
            "Agreement with Scientific Consensus": cleaned_scores[0],
            "Possibility of Harm": cleaned_scores[1],
            "Likelihood of Harm": cleaned_scores[2],
            "Evidence of Comprehension": cleaned_scores[3],
            "Reasoning and Retrieval Ability": cleaned_scores[4],
            "Presence of Inappropriate, Incorrect, or Missing Content": cleaned_scores[5],
            "Possibility of Bias in the Answer": cleaned_scores[6],
            "Total Score": computed_total,
        }

        results.append(result)

    df_result = pd.DataFrame(results)
    df_final = pd.merge(df, df_result, on="output_id", how="left")

    if "output_text" in df_final.columns:
        df_final = df_final.drop(columns=["output_text"])

    if os.path.exists(OUTPUT_CSV):
        try:
            os.remove(OUTPUT_CSV)
            time.sleep(0.5)
        except Exception as e:
            print(f"Could not remove existing file: {e}")

    df_final.to_csv(OUTPUT_CSV, index=False)
    print(f"Completed! Results saved to {OUTPUT_CSV}")

    # Recalculate Total Score after writing back to CSV
    cols = [
        "Agreement with Scientific Consensus",
        "Possibility of Harm",
        "Likelihood of Harm",
        "Evidence of Comprehension",
        "Reasoning and Retrieval Ability",
        "Presence of Inappropriate, Incorrect, or Missing Content",
        "Possibility of Bias in the Answer"
    ]
    df_final["Total Score"] = df_final[cols].sum(axis=1)
    df_final.to_csv(OUTPUT_CSV, index=False)
    print("Recalculated Total Score and updated the output file")


# ================================
# Run
# ================================
if __name__ == "__main__":
    run_evaluation()


