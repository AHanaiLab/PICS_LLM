import subprocess
import pandas as pd
import os
import time
import shutil
import sys

# ================================
# Command-line arguments
# ================================
if len(sys.argv) < 3:
    print("Usage: python summary_runner.py <arg0> <arg1>")
    print("Example: python summary_runner.py GPT MD")
    sys.exit(1)

arg0 = sys.argv[1]
arg1 = sys.argv[2]

# Replace ':' with '.' for safe filenames
arg0_dot = arg0_raw.replace(":", ".")


# ================================
# Dynamic settings from arguments
# ================================
EVAL_SCRIPT = f"GPT_score.py"  #EVAL_SCRIPT = f"ollama_score.py"
INPUT_CSV = f"{arg0_dot}_{arg1}.csv"
OUTPUT_MEAN_CSV = f"{arg0_dot}_{arg1}_mean.csv"
N_RUNS = 5  # Number of runs

print(f"Using evaluation script: {EVAL_SCRIPT}")
print(f"Using input CSV: {INPUT_CSV}")
print(f"Output mean CSV: {OUTPUT_MEAN_CSV}")

# Score columns (8 columns)
SCORE_COLS = [
    "Agreement with Scientific Consensus",
    "Possibility of Harm",
    "Likelihood of Harm",
    "Evidence of Comprehension",
    "Reasoning and Retrieval Ability",
    "Presence of Inappropriate, Incorrect, or Missing Content",
    "Possibility of Bias in the Answer",
    "Total Score"
]

# ================================
# Dictionary to store results
# {output_id: {column_name: [values...]}}
# ================================
scores_dict = {}

# ================================
# Run evaluation script N times
# ================================
for run in range(1, N_RUNS + 1):
    print(f"\nRunning evaluation {run}/{N_RUNS}...")

    # Run the evaluation script *with arguments*
    subprocess.run(["python", EVAL_SCRIPT, arg0, arg1], check=True)

    # Check if output CSV exists
    if not os.path.exists(INPUT_CSV):
        raise FileNotFoundError(f"{INPUT_CSV} not found.")

    # ===============================================
    # Save the result of each run as a separate file
    # ===============================================
    base, ext = os.path.splitext(INPUT_CSV)
    output_csv_run = f"{base}_{run}{ext}"
    shutil.copy(INPUT_CSV, output_csv_run)
    print(f"Saved run {run} result to {output_csv_run}")
    # ===============================================

    df = pd.read_csv(INPUT_CSV)

    # Accumulate data for each output_id
    for _, row in df.iterrows():
        output_id = row["output_id"]
        if output_id not in scores_dict:
            scores_dict[output_id] = {col: [] for col in SCORE_COLS}

        for col in SCORE_COLS:
            scores_dict[output_id][col].append(row[col])

    print(f"Saved results from run {run}.")
    time.sleep(1)

# ================================
# Calculate mean values
# ================================
records = []
for output_id, item_scores in scores_dict.items():
    record = {"output_id": output_id}
    for col in SCORE_COLS:
        values = item_scores[col]
        mean_val = sum(values) / len(values) if values else 0
        record[col] = round(mean_val, 2)
    records.append(record)

df_mean = pd.DataFrame(records)

# ================================
# Export averaged results to CSV
# ================================
df_mean.to_csv(OUTPUT_MEAN_CSV, index=False)
print(f"\nSaved averaged results to {OUTPUT_MEAN_CSV}.")


