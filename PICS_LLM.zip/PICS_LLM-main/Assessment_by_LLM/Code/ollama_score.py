import pandas as pd
import time
from tqdm import tqdm
import os
import csv
import io
import random
import requests
import sys

# ================================
# Command-line arguments
# ================================
if len(sys.argv) < 3:
    print("Usage: python script.py <arg0> <arg1>")
    print("Example: python evaluate.py llama3:latest MD")
    sys.exit(1)

arg0 = sys.argv[1]   # model name
arg1 = sys.argv[2]   # MD or Pt

# Role-specific first sentence
if arg1 == "MD":
    role_sentence = "You are a medical doctor with extensive experience in emergency care."
elif arg1 == "Pt":
    role_sentence = "You are a family member of a patient in the intensive care unit."
else:
    raise ValueError("arg1 must be 'MD' or 'Pt'.")

# Replace ':' with '.' for safe filenames
arg0_dot = arg0.replace(":", ".")

# ================================
# Settings
# ================================
INPUT_CSV = "output.csv"
OUTPUT_CSV = f"{arg0_dot}_{arg1}.csv"

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL_NAME = f"{arg0}"
MAX_RETRIES = 3
SLEEP_SEC = 3

# ================================
# Evaluation Prompt
# ================================
EVAL_PROMPT_TEMPLATE = """
{role_sentence}
Evaluate the following patient-education-style output about Post-Intensive Care Syndrome (PICS)
on these 7 criteria. Score each on a 1–10 scale, where 10 is best and 1 is worst.

Criteria:
1. Agreement with Scientific Consensus
2. Possibility of Harm
3. Likelihood of Harm
4. Evidence of Comprehension
5. Reasoning and Retrieval Ability
6. Presence of Inappropriate, Incorrect, or Missing Content
7. Possibility of Bias in the Answer

Output:
\"\"\"{output}\"\"\"\"

Respond **strictly as a CSV row** with these headers:
Agreement with Scientific Consensus,Possibility of Harm,Likelihood of Harm,Evidence of Comprehension,Reasoning and Retrieval Ability,Presence of Inappropriate,Incorrect,or Missing Content,Possibility of Bias in the Answer

Do NOT include any Total Score column.
Do NOT include text, explanations, or comments — only one CSV row with exactly 7 numbers.
"""

# ================================
# CSV parsing utility
# ================================
def parse_csv_from_response(content):
    """
    Strictly parses the CSV output from GPT/Ollama, returning only the first 7 items.
    If an 8th "Total" column appears, it is ignored entirely.
    """
    content = content.replace("```csv", "").replace("```", "").strip()
    reader = csv.reader(io.StringIO(content))

    for row in reader:
        row = [c.strip() for c in row if c is not None and c.strip() != ""]
        if len(row) >= 7:
            try:
                scores = []
                for i in range(7):
                    val = row[i]
                    val_clean = "".join(ch for ch in val if (ch.isdigit() or ch in ".-"))
                    if val_clean == "":
                        raise ValueError("empty score")
                    scores.append(float(val_clean))
                return scores
            except Exception:
                continue
    return None

# ================================
# Ollama caller
# ================================
def evaluate_with_ollama(output_text):
    """
    Calls Ollama locally and returns only the 7 evaluation scores.
    Structured to be compatible with evaluate_with_gpt().
    """
    prompt = EVAL_PROMPT_TEMPLATE.format(output=output_text)
    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.1,
        }
    }

    for retry in range(MAX_RETRIES):
        try:
            response = requests.post(OLLAMA_URL, json=payload, timeout=60)

            if response.status_code != 200:
                print(f"Ollama HTTP {response.status_code} (retry {retry+1}/{MAX_RETRIES})")
                time.sleep(SLEEP_SEC)
                continue

            content = response.json().get("response", "").strip()
            scores = parse_csv_from_response(content)

            if scores is not None:
                return scores

        except Exception as e:
            print(f"Ollama Error ({retry+1}/{MAX_RETRIES}): {e}")
            time.sleep(SLEEP_SEC * (2 ** retry))

    return None

# ================================
# Main evaluation procedure
# ================================
def run_evaluation():
    df = pd.read_csv(INPUT_CSV)
    results = []
    processed = 0

    for idx, row in tqdm(df.iterrows(), total=len(df)):
        if idx < processed:
            continue

        output_text = row["output_text"]
        parsed_scores = evaluate_with_ollama(output_text)

        if parsed_scores:
            cleaned_scores = [int(round(max(0, min(10, s)))) for s in parsed_scores]
            computed_total = sum(cleaned_scores)
        else:
            cleaned_scores = [0] * 7
            computed_total = 0

        result = {
            "output_id": row["output_id"],
            "Agreement with Scientific Consensus": cleaned_scores[0],
            "Possibility of Harm": cleaned_scores[1],
            "Likelihood of Harm": cleaned_scores[2],
            "Evidence of Comprehension": cleaned_scores[3],
            "Reasoning and Retrieval Ability": cleaned_scores[4],
            "Presence of Inappropriate, Incorrect, or Missing Content": cleaned_scores[5],
            "Possibility of Bias in the Answer": cleaned_scores[6],
            "Total Score": computed_total,
        }

        results.append(result)

    df_result = pd.DataFrame(results)
    df_final = pd.merge(df, df_result, on="output_id", how="left")

    if "output_text" in df_final.columns:
        df_final = df_final.drop(columns=["output_text"])

    if os.path.exists(OUTPUT_CSV):
        try:
            os.remove(OUTPUT_CSV)
            time.sleep(0.5)
        except Exception as e:
            print(f"Could not remove existing file: {e}")

    df_final.to_csv(OUTPUT_CSV, index=False)
    print(f"Completed! Results saved to {OUTPUT_CSV}")

    cols = [
        "Agreement with Scientific Consensus",
        "Possibility of Harm",
        "Likelihood of Harm",
        "Evidence of Comprehension",
        "Reasoning and Retrieval Ability",
        "Presence of Inappropriate, Incorrect, or Missing Content",
        "Possibility of Bias in the Answer"
    ]
    df_final["Total Score"] = df_final[cols].sum(axis=1)
    df_final.to_csv(OUTPUT_CSV, index=False)
    print("Recalculated Total Score and saved updated results.")

# ================================
# Execution
# ================================
if __name__ == "__main__":
    run_evaluation()




